# Research notes — CT Artisanal Pantry

## Sources
- GitHub repo `ahsanilyas010/ctartisanalpantry` — CONFIRMED EMPTY (tree API 409 on main/master, no README). Not usable as a code source.
- Logo: `uploads/WhatsApp Image 2026-07-03 at 3.21.24 PM.jpeg` — red monogram "CT" (serif, C in red overlapping T), wordmark "ARTISANAL" (large serif, letterspaced) / "PANTRY" (smaller serif, letterspaced) below, thin horizontal rule, Instagram glyph + "CHEFLINGTALES" handle underneath. White background. Red used only in monogram; wordmark is black/near-black serif.
- Google Doc "CT Artisanal Pantry: Web Copy" — full text pasted by user below.

## Brand
Madagascar-sourced artisanal ingredients (vanilla, peppercorn, cocoa, chili oil). Elegant, whitespace-heavy, small serif headings. Instagram: @chefflingtales.

## Full web copy (from doc)

### 1) Hero Section (First Screen)
Headline: "CT Artisanal Pantry curates exceptional ingredients from the remarkable landscape of Madagascar" / "Crafted, sourced, and selected for cooks who care deeply about flavour."
Buttons: "Explore the Pantry" / "Discover Chili Oil"

### 2) Product Grid – The Pantry
Clean 4-column layout. Each product: square image, minimal title, small descriptor.
- Madagascar Bourbon Vanilla — Warm, floral, and deeply aromatic.
- Wild Red Peppercorn — Bright spice with delicate citrus warmth.
- Single-Origin Cocoa — Pure cocoa with deep chocolate intensity.
- Chili Oil — The Art of Heat — Layered warmth crafted in small batches.
Design rule: Lots of whitespace, small elegant serif headings.

### 3) Signature Product Highlight — Chili Oil
Left: product image. Right: text.
Headline: "The Art of Heat"
Copy: "Crafted in small batches, our chili oil delivers warmth with depth and balance. Designed to elevate simple dishes—from eggs and noodles to roasted vegetables and soups."
Button: "Shop Chili Oil"

### 4) Our Philosophy
Simple typography on white background. Headline: "Our Pantry Philosophy"
Four icons/lines:
- Origin — Exceptional growing regions.
- Purity — Clean, carefully selected ingredients.
- Craft — Small-batch production.
- Modern Pantry — Designed for contemporary kitchens.

### Landscape Story Section
Large landscape photography.
Headline: "Where Flavour Begins"
Text: "Climate, soil, and cultivation shape the character of every ingredient in our pantry. From Madagascar's fertile landscapes to remarkable growing regions around the world, each ingredient reflects the place it comes from."
Button: "Explore Origins"

### 5) Recipe Inspiration
Grid of simple dishes: Cocoa Milk Shake, Chili Oil Eggs, Vanilla Custard, Peppercorn Roasted Vegetables.
Headline: "In the Kitchen"
Button: "View Recipes"

### 6) Newsletter Section
Soft beige background.
Headline: "Join the Pantry"
Text: "Be the first to discover new ingredients, recipes, and seasonal releases."
Email field + Subscribe button.

### 7) Footer
Minimal. Logo. Tagline: "Flavour, Shaped by Place"
Links: Shop / Our Story / Origins / Recipes / Contact
Instagram

## Tone/content takeaways
- Elegant, sensory, place-driven copy ("remarkable landscape of Madagascar", "Where Flavour Begins")
- Short headline + one-line descriptor pattern throughout
- No exclamation marks, no emoji, understated luxury food-brand voice
- "The Art of Heat" — poetic product framing
- Em-dashes used for descriptor pairs ("Chili Oil — The Art of Heat")

## Plan status
- No codebase/Figma to source components from → author standard component set (Button, Card, Input, etc.) sized to brand.
- No product screenshots beyond logo → build single UI kit: marketing website (7 sections above) as ui_kits/website.
- Need to pick fonts: elegant display serif (e.g. Fraunces alt, or a refined serif like "Cormorant"/"Canela"-like — but avoid Fraunces per anti-slop guidance; consider " 완 not available... use Google Fonts: "Cormorant Garamond" or "Marcellus" for headlines, clean sans for body e.g. "Inter" is banned... use "Public Sans" or "Karla"). Will decide during typography step.
- Color: white/cream background, black/near-black text, red (#C81D25-ish, sample from logo) as accent, soft beige for newsletter section.
