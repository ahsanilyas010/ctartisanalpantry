---
name: ct-artisanal-pantry-design
description: Use this skill to generate well-branded interfaces and assets for CT Artisanal Pantry, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Notes specific to this brand:
- Fonts (Cormorant Garamond / Work Sans) are a Google Fonts substitution, not the brand's real typeface — flag this if producing final production assets.
- No real product/lifestyle photography was supplied — use labeled placeholders and ask the user for real imagery before shipping anything final.
- No icon system was supplied — do not invent icon artwork; use plain type/numbering until a real icon system is confirmed.
- The GitHub repo `ahsanilyas010/ctartisanalpantry` was empty when this system was built — check it again for real frontend code, and prefer it over this system's original components if it now contains one.
