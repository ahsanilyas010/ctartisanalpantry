# CT Artisanal Pantry — Design System

CT Artisanal Pantry (Instagram: [@chefflingtales](https://instagram.com/chefflingtales)) is a small artisanal-foods brand curating exceptional ingredients sourced from Madagascar and other remarkable growing regions — Madagascar bourbon vanilla, wild red peppercorn, single-origin cocoa, and a signature small-batch chili oil. The brand voice is elegant, sensory, and understated: an editorial pantry brand, not a mass-market grocery label.

This system was built from two sources:
- **Logo**: a supplied brand mark (`uploads/WhatsApp Image 2026-07-03 at 3.21.24 PM.jpeg`), cropped into `assets/logo/`.
- **Web copy doc**: the client's own draft copy for a marketing website ("CT Artisanal Pantry: Web Copy"), describing a 7-section homepage (hero, product grid, signature product, philosophy, origin story, recipes, newsletter, footer). Full text preserved in `research_notes.md`.
- **GitHub repo `ahsanilyas010/ctartisanalpantry`** was attached as a design-system source but is **empty** (no commits) — nothing could be read from it. If real frontend code exists elsewhere, re-attach it and this system should be revised to match it exactly (see Caveats below).

No Figma file or existing UI code was available, so this system's typography, color, spacing, and component set are **originated from the logo + copy deck**, not lifted from an existing product. Treat this as v1 — the honest next step is to validate it against real site design or code once available.

## Caveats — please read
- **No real photography** was supplied. Every image slot in the marketing website template (hero background, chili-oil product shot, landscape/origin photography, recipe images, product grid tiles) is a flat labeled placeholder. Please supply real photography and swap it in.
- **No icon set** was supplied for the "Our Philosophy" section (Origin / Purity / Craft / Modern Pantry). Rather than inventing icons, the template renders these as numbered labels (01–04). If the brand has an icon style in mind, tell us and we'll build it in.
- **Fonts are a substitution**, not the brand's real typeface files — see Visual Foundations → Type below. Flagging for confirmation.
- **The component set is originated, not sourced** — with no code or Figma to enumerate an existing inventory, we authored a standard, brand-appropriate primitive set (Button, Card, Input, Badge, SectionEyebrow, ProductCard) sized to what the one-page site copy actually needs, not a generic full component library.

## Content fundamentals

**Voice**: warm, precise, sensory — never hard-sell. Copy leans on place ("the remarkable landscape of Madagascar"), craft ("crafted in small batches"), and restraint. No exclamation points, no emoji, no urgency language ("Buy now!", "Limited time!").

**Point of view**: mostly third-person/brand-voice ("CT Artisanal Pantry curates…"), occasionally addressing the cook directly ("Designed to elevate simple dishes"). Never uses "I"; "you" appears only implicitly, never as a direct address in the sampled copy.

**Casing**: sentence case throughout body copy and headlines (never Title Case, never ALL CAPS) — capitalization is reserved for short UI labels (nav items, buttons, eyebrows), which run in small-caps-style uppercase with wide letterspacing.

**Structural pattern**: nearly every section follows *eyebrow label → short serif headline → one or two lines of sensory copy → single button*. Product tiles follow *title → one descriptor line* ("Madagascar Bourbon Vanilla — Warm, floral, and deeply aromatic."), sometimes joined with an em dash when title and framing combine ("Chili Oil — The Art of Heat").

**Vocabulary favorites**: flavour (UK spelling — keep it), crafted, curated, small-batch, remarkable, exceptional, layered, depth and balance, seasonal.

**Emoji**: none used anywhere in the source copy. Do not introduce any.

## Visual foundations

**Color**: a near-white/cream page background (`--cream-50`), a single saturated brand red sampled directly from the logo monogram (`--red-500 / #E2202D`) used sparingly as an accent — for eyebrow labels, primary buttons, and CTA emphasis — never as a dominant fill. A soft beige (`--cream-200`) marks the one section the copy explicitly calls out as tinted (the newsletter block). Text runs in a warm charcoal ink (`--ink-900`), never pure black. No secondary hue family; no gradients anywhere.

**Type**: an elegant, high-contrast serif for all headlines (paired with the logo's own serif wordmark) and a clean, neutral sans for body copy, descriptors, and UI labels — see Type substitution note below. Headline sizes are large and generous (44–64px on desktop); body copy stays comfortably readable (16–19px). UI labels (nav, buttons, eyebrows) are small, uppercase, and wide-tracked (`--ls-wide` / `--ls-wider`), mirroring the logo's letterspaced "ARTISANAL PANTRY" wordmark.

**Spacing**: generous whitespace is the brand's primary luxury cue — the copy deck explicitly calls this out ("Lots of whitespace. small, elegant serif headings."). Sections use large vertical rhythm (64–96px between major blocks); grids (products, recipes) use wide gutters, never a tight commerce-density grid.

**Backgrounds**: flat color only — no textures, patterns, or illustration. One full-bleed photography moment (the "Where Flavour Begins" origin/landscape section) breaks the otherwise white/cream canvas; product and recipe imagery is square-cropped, not full-bleed. No hand-drawn illustration anywhere in the source.

**Animation**: the source copy implies none explicitly; treat as a quiet, editorial site — favor simple opacity/color transitions only (150–250ms, standard ease), no bounces, no scroll-triggered parallax, no looping motion.

**Hover states**: primary buttons darken one step (`--accent` → `--accent-hover`); outline buttons invert to a solid ink fill on hover; text-style links shift from ink to accent red. No lightening-on-hover, no shadow-pop.

**Press/active states**: darken one step further (`--accent-active`); no scale/shrink micro-interaction implied by the source material.

**Borders**: hairline (1px), warm-neutral (`--border-subtle` / `--border-default`), never colored. No colored left-border card accents.

**Shadows**: soft and warm-tinted (shadow color is ink-based, not cool gray), used sparingly — one elevated card in the landscape/origin section, nowhere else. Most cards (product tiles) carry no shadow at all, relying on whitespace for separation.

**Corner radii**: mostly square. Cards use a small 8px radius at most; buttons are the one fully-pill-shaped element (`--radius-pill`), consistent with an elegant, editorial (not softly-rounded-app) feel.

**Cards**: flat, hairline-bordered, no shadow by default (`Card` component); the one "elevated" variant (soft shadow, no border) is reserved for the origin-story overlay card. Product tiles skip the card chrome entirely — just an image, a title, and a descriptor line, floating in whitespace.

**Transparency/blur**: none observed or implied in the source; not used.

**Imagery color vibe**: not directly observable (no photography supplied) — but the copy's language ("Madagascar's fertile landscapes," "warm, floral," "deep chocolate intensity") points toward warm, saturated, natural-light food/landscape photography rather than cool or desaturated tones. Placeholder blocks are neutral gray/ink to avoid asserting a look we haven't confirmed.

### Type — font substitution (flagged)
No brand font files were supplied. The logo's wordmark is a refined, high-contrast serif with wide caps letterspacing; no exact open-source match was identified. Substituted via Google Fonts:
- **Display serif** → *Cormorant Garamond* (headlines)
- **Body / UI sans** → *Work Sans* (body copy, labels, buttons)

**Please supply the real brand typeface files if you have them** — we'll swap these tokens over immediately.

## Iconography
No icon system, icon font, or SVG/PNG icon set was supplied. The "Our Pantry Philosophy" section (Origin / Purity / Craft / Modern Pantry) is the only place the source copy calls for icons ("Four icons or simple lines"); rather than inventing icon artwork, the template renders plain numbered labels (01–04) so the layout is real but the iconography is honestly left open. Nothing in the source uses emoji or unicode-glyph icons. If you'd like a specific icon system (a line-icon set like Lucide/Phosphor, or the brand's own custom marks), let us know and we'll wire it in properly.

## Components
Standard primitive set, originated for this brand (no existing component library was available to source from — see Caveats):
- **Button** (`components/core/Button.jsx`) — pill CTA, variants `primary` / `outline` / `inverse` / `text`
- **Card** (`components/core/Card.jsx`) — flat bordered content container
- **SectionEyebrow** (`components/core/SectionEyebrow.jsx`) — uppercase wide-tracked micro-label
- **Badge** (`components/core/Badge.jsx`) — small pill tag
- **Input** (`components/forms/Input.jsx`) — text field (used for newsletter capture)
- **ProductCard** (`components/commerce/ProductCard.jsx`) — square image + title + descriptor tile, the core "Pantry" grid unit

### Intentional additions
None of the above are inventions beyond what the one-page site copy requires — every component maps directly to a UI need named in the source copy (buttons, product tiles, the newsletter field, section labels). No speculative additions (Toast, Tabs, Dialog, etc.) were made since nothing in the source calls for them.

## Index
- `styles.css` — root stylesheet; imports everything under `tokens/`
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `fonts.css`
- `components/core/` — Button, Card, SectionEyebrow, Badge
- `components/forms/` — Input
- `components/commerce/` — ProductCard
- `guidelines/` — foundation specimen cards (colors, type, spacing, radius/shadow, brand logo)
- `assets/logo/` — cropped logo lockup + standalone monogram, from the supplied brand image
- `templates/marketing-website/` — full homepage template (`MarketingWebsite.dc.html`), covering all 7 sections from the copy deck
- `research_notes.md` — full source copy text + research trail
- `SKILL.md` — portable skill file for using this system in Claude Code

## Sources
- GitHub: [ahsanilyas010/ctartisanalpantry](https://github.com/ahsanilyas010/ctartisanalpantry) — attached but empty at time of writing; explore it again once it has content, and update this system to match real code if it differs from what's here.
- Web copy doc: "CT Artisanal Pantry: Web Copy" (Google Doc, full text mirrored in `research_notes.md`)
- Logo: user-supplied image, `uploads/WhatsApp Image 2026-07-03 at 3.21.24 PM.jpeg`
