import React from "react";

export function ProductCard({ image, title, descriptor, imageAlt = "" }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
      <div
        style={{
          aspectRatio: "1 / 1",
          background: image ? `center / cover no-repeat url(${image})` : "var(--surface-muted)",
          borderRadius: "var(--radius-md)",
        }}
        role="img"
        aria-label={imageAlt}
      />
      <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
        <h3
          style={{
            font: "var(--text-h3)",
            color: "var(--text-primary)",
            margin: 0,
          }}
        >
          {title}
        </h3>
        <p
          style={{
            font: "var(--text-body-sm)",
            color: "var(--text-muted)",
            margin: 0,
          }}
        >
          {descriptor}
        </p>
      </div>
    </div>
  );
}
