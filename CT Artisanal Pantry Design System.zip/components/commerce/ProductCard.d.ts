import * as React from "react";

export interface ProductCardProps {
  /** Image URL. Falls back to a muted placeholder block when omitted. */
  image?: string;
  imageAlt?: string;
  title: string;
  /** One-line sensory descriptor, e.g. "Warm, floral, and deeply aromatic." */
  descriptor: string;
}
