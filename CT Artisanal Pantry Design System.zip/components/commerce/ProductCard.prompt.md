The core product-grid tile from "The Pantry" section: a square image, a small serif title, and a one-line sensory descriptor beneath it. No price, no badges, no borders — whitespace and typography carry the design.

```jsx
<ProductCard
  image="/assets/imagery/vanilla.jpg"
  title="Madagascar Bourbon Vanilla"
  descriptor="Warm, floral, and deeply aromatic."
/>
```

Lay tiles out in a 4-column grid (see ui_kits/website) with generous gutters — never compress this into a dense commerce grid.
