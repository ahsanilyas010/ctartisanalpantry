import React from "react";

const PADDING = {
  sm: "10px 20px",
  md: "14px 28px",
  lg: "16px 36px",
};

const FONT_SIZE = {
  sm: "var(--fs-label)",
  md: "var(--fs-body-sm)",
  lg: "var(--fs-body)",
};

function variantStyle(variant) {
  switch (variant) {
    case "primary":
      return {
        background: "var(--accent)",
        color: "var(--text-on-accent)",
        border: "1px solid var(--accent)",
      };
    case "outline":
      return {
        background: "transparent",
        color: "var(--text-primary)",
        border: "1px solid var(--text-primary)",
      };
    case "inverse":
      return {
        background: "var(--surface-page)",
        color: "var(--text-primary)",
        border: "1px solid var(--surface-page)",
      };
    case "text":
    default:
      return {
        background: "transparent",
        color: "var(--text-primary)",
        border: "none",
        padding: 0,
        textUnderlineOffset: "6px",
      };
  }
}

export function Button({
  children,
  variant = "primary",
  size = "md",
  disabled = false,
  as = "button",
  href,
  onClick,
  style,
}) {
  const vStyle = variantStyle(variant);
  const isText = variant === "text";
  const Tag = as === "a" ? "a" : "button";

  const base = {
    fontFamily: "var(--font-sans-body)",
    fontSize: FONT_SIZE[size],
    letterSpacing: "var(--ls-wide)",
    textTransform: "uppercase",
    fontWeight: "var(--fw-medium)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.45 : 1,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "8px",
    borderRadius: "var(--radius-pill)",
    transition: "background var(--duration-fast) var(--ease-standard), color var(--duration-fast) var(--ease-standard), border-color var(--duration-fast) var(--ease-standard)",
    textDecoration: isText ? "underline" : "none",
    padding: isText ? 0 : PADDING[size],
    ...vStyle,
    ...style,
  };

  return (
    <Tag
      href={as === "a" ? href : undefined}
      disabled={as === "button" ? disabled : undefined}
      onClick={disabled ? undefined : onClick}
      style={base}
      onMouseEnter={(e) => {
        if (disabled) return;
        if (variant === "primary") e.currentTarget.style.background = "var(--accent-hover)";
        if (variant === "outline") { e.currentTarget.style.background = "var(--text-primary)"; e.currentTarget.style.color = "var(--surface-page)"; }
        if (variant === "text") e.currentTarget.style.color = "var(--accent)";
      }}
      onMouseLeave={(e) => {
        if (disabled) return;
        if (variant === "primary") e.currentTarget.style.background = "var(--accent)";
        if (variant === "outline") { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "var(--text-primary)"; }
        if (variant === "text") e.currentTarget.style.color = "var(--text-primary)";
      }}
    >
      {children}
    </Tag>
  );
}
