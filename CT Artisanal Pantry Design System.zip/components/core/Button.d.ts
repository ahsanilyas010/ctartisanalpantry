import * as React from "react";

export interface ButtonProps {
  children: React.ReactNode;
  /** Visual style. `primary` = solid accent fill. `outline` = ink border, fills on hover. `inverse` = for use on dark/accent backgrounds. `text` = underlined link-style button (used for in-copy CTAs like "Explore the Pantry"). */
  variant?: "primary" | "outline" | "inverse" | "text";
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  /** Render as an anchor instead of a button. */
  as?: "button" | "a";
  href?: string;
  onClick?: () => void;
  style?: React.CSSProperties;
}
