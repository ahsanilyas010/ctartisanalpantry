import * as React from "react";

export interface SectionEyebrowProps {
  children: React.ReactNode;
  tone?: "default" | "accent";
  style?: React.CSSProperties;
}
