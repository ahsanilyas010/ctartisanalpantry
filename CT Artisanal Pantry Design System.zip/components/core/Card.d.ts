import * as React from "react";

export interface CardProps {
  children: React.ReactNode;
  /** CSS padding shorthand. Defaults to a generous 32px. */
  padding?: string;
  /** Flat bordered card (default) vs. a borderless, shadow-elevated card. */
  elevated?: boolean;
  style?: React.CSSProperties;
}
