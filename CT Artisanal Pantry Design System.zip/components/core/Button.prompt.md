Pill-shaped call-to-action button; the brand's single button primitive, used for both standalone CTAs and inline copy links.

```jsx
<Button variant="primary">Explore the Pantry</Button>
<Button variant="outline">Shop Chili Oil</Button>
<Button variant="text">Discover Chili Oil →</Button>
```

Variants: `primary` (solid red fill, for the one key action per section), `outline` (ink border, inverts to filled ink on hover — secondary actions), `inverse` (light fill, for use on the dark/ink footer or accent-soft sections), `text` (underlined, no padding — used for lightweight in-copy CTAs). Sizes: `sm`, `md`, `lg`. Labels render uppercase with wide letterspacing, matching the logo wordmark's caps treatment.
