import React from "react";

export function Card({ children, padding = "var(--space-6)", style, elevated = false }) {
  return (
    <div
      style={{
        background: "var(--surface-card)",
        border: elevated ? "none" : "1px solid var(--border-subtle)",
        boxShadow: elevated ? "var(--shadow-md)" : "none",
        borderRadius: "var(--radius-lg)",
        padding,
        ...style,
      }}
    >
      {children}
    </div>
  );
}
