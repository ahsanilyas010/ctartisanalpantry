import React from "react";

export function SectionEyebrow({ children, tone = "default", style }) {
  return (
    <div
      style={{
        fontFamily: "var(--font-sans-body)",
        fontSize: "var(--fs-label)",
        fontWeight: "var(--fw-medium)",
        letterSpacing: "var(--ls-wider)",
        textTransform: "uppercase",
        color: tone === "accent" ? "var(--accent)" : "var(--text-muted)",
        ...style,
      }}
    >
      {children}
    </div>
  );
}
