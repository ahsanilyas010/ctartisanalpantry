Plain content container — flat-bordered by default, matching the brand's low-ornamentation, mostly-square editorial cards.

```jsx
<Card>
  <p>Any content</p>
</Card>
<Card elevated>Elevated variant for callouts</Card>
```

Corner radius is subtle (`--radius-lg`, 8px) — never pill-shaped or heavily rounded. Default has a hairline border, no shadow; `elevated` swaps the border for a soft warm-toned shadow. Do not add colored left-border accents — not part of this brand's visual language.
