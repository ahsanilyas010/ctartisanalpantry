Small uppercase pill used for lightweight categorization (e.g. an ingredient origin or "New" flag on a product tile).

```jsx
<Badge tone="accent">Single-Origin</Badge>
```

Tones: `neutral` (muted parchment), `accent` (soft red), `inverse` (for dark backgrounds). Use sparingly — this brand favors whitespace and typography over label clutter.
