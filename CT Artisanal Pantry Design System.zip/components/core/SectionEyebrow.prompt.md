Small uppercase, wide-letterspaced label placed above a serif headline — the recurring rhythm across every section in the source copy (eyebrow above "Our Pantry Philosophy", "Where Flavour Begins", etc).

```jsx
<SectionEyebrow>The Pantry</SectionEyebrow>
<h2>Product Grid</h2>
```

`tone="accent"` renders in brand red; default renders in muted ink. Always paired with a serif headline directly below it.
