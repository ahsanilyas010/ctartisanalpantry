import React from "react";

export function Badge({ children, tone = "neutral" }) {
  const tones = {
    neutral: { background: "var(--surface-muted)", color: "var(--text-secondary)" },
    accent: { background: "var(--accent-soft)", color: "var(--accent-hover)" },
    inverse: { background: "var(--surface-inverse)", color: "var(--text-on-inverse)" },
  };
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        fontFamily: "var(--font-sans-body)",
        fontSize: "11px",
        fontWeight: "var(--fw-medium)",
        letterSpacing: "var(--ls-wide)",
        textTransform: "uppercase",
        padding: "5px 12px",
        borderRadius: "var(--radius-pill)",
        ...tones[tone],
      }}
    >
      {children}
    </span>
  );
}
