Single-line text field — used for the newsletter email capture ("Join the Pantry") and any other form entry.

```jsx
<Input type="email" placeholder="Your email address" />
```

Squared-off corners (4px), hairline border that darkens to ink on focus. Typically paired with a `Button` alongside it (see the Newsletter pattern in the website UI kit).
