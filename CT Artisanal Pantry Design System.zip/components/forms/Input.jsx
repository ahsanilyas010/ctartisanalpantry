import React from "react";

export function Input({
  type = "text",
  placeholder,
  value,
  onChange,
  style,
}) {
  return (
    <input
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      style={{
        fontFamily: "var(--font-sans-body)",
        fontSize: "var(--fs-body)",
        color: "var(--text-primary)",
        background: "var(--surface-card)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-md)",
        padding: "14px 18px",
        width: "100%",
        boxSizing: "border-box",
        outline: "none",
        transition: "border-color var(--duration-fast) var(--ease-standard)",
        ...style,
      }}
      onFocus={(e) => (e.currentTarget.style.borderColor = "var(--text-primary)")}
      onBlur={(e) => (e.currentTarget.style.borderColor = "var(--border-default)")}
    />
  );
}
